# darbit — neon linear body experiments

These are **color-only** variants derived from `turf_gb_emerald`, updated to increase visibility on dark backgrounds.

## What changed
- **Top knob**: kept as **turf green**.
- **Body**: switched to **brighter linear gradients** that blend **pastel neon blue + purple** (with a teal/emerald start) so the gradient reads clearly.
- **Shadow overlay**: slightly reduced opacity so the body doesn't collapse into dark tones.

## Files
- `svg/*_master.svg` — smooth gradients
- `svg/*_flatsteps.svg` — step/banded gradients (icon-crisper)
- `png_master/*` — raster exports from master SVG
- `png_flatsteps/*` — raster exports from flatsteps SVG
- `previews/*` — quick side-by-side and scale strips

## Variants + headFill stops
### balanced
- #34D399 → #60A5FA → #A78BFA

### pastel
- #5EEAD4 → #7DD3FC → #C4B5FD

### electric
- #2DD4BF → #38BDF8 → #8B5CF6
